

function MetinIslemleri()
{
    var isim = "Vedat"; // Global de�i�ken tan�mlama. B�t�n veri bloklar�ndan eri�ilebilir.

    let username = "vedat"; // lokal - yerel de�i�kenler i�in.

    if (username == "vedat") {
        alert('kullanici adi dogru');
    }
    else {
        alert('kullanici adi yanlis');
    }

    const kdv = 0.2; // constant - sabit - program boyunca de�eri de�i�meyecek haf�za alan� tan�mlamas� i�in kullan�l�r. �lk atamadan sonra i�indeki veri de�i�mez.


   // kdv = 0.15;  //tekrar atamay� kabul etmez.

}


function Login() {
    var username = document.getElementById("UserName");
    var password = document.getElementById("Password");
    var mesajKutusu = document.getElementById("Mesaj");
    
    if (username.value == "vedat" && password.value == "1234") {
        mesajKutusu.innerHTML = "Bilgiler Do�ru Girildi...";
        window.open("https://www.aribilgi.com", "_blank");
    }
    else {
        mesajKutusu.innerHTML = "Bilgiler Yanl�� Girildi...";

        username.value = "";
        password.value = "";
    }
}

function Hesapla(islem) {
    let Sonuc = 0;

    let sayi1 = parseInt(document.getElementById("Sayi1").value);
    let sayi2 = parseInt(document.getElementById("Sayi2").value);
    let sonucKutusu = document.getElementById("Sonuc");

    if (sayi1 == null || sayi2 == null) {
        sonucKutusu.value = 0;
        return;
    }

    if (islem == "Topla") {
        Sonuc = sayi1 + sayi2 ;
    }
    else if (islem == "Cikart") {
        Sonuc = sayi1 - sayi2;
    }
    else if (islem == "Carp") {
        Sonuc = sayi1 * sayi2;
    }
    else if (islem == "Bol") {
        Sonuc = sayi1 / sayi2;
    }
    else {
        Sonuc = 0;
    }

    sonucKutusu.value = Sonuc;
}

function KDV() {
    let gelenFiyat = parseFloat(document.getElementById("fiyat").value);
    let gelenKdvOran = parseFloat(document.getElementById("kdvOran").value);
    let sonucKutusu = document.getElementById("KDVSonuc");

    sonucKutusu.value = KDVHesapla(gelenFiyat, gelenKdvOran);
}

function KDVHesapla(fiyat, kdvOrani) {
    return fiyat * kdvOrani;
}

function DegiskenTest() {

    console.log(" var ----------------------------");

    var isim = "Ali'nin defteri";

    //alert(isim);
    //document.write(isim);

    console.log(isim);

    var adet = 55;

    console.log(adet);

    var kdvOrani = 0.2;

    console.log(kdvOrani);

    console.log(adet * kdvOrani);

    var adet = 100; // var ile ayn� scope i�inde ayn� isimli de�i�kenler tekrar yarat�labilir. (Recreation) 

    console.log(adet);

            {
                var kdvOrani = 0.1; // var ile tan�mlanan de�i�kenler t�m kod bloklar�nda ge�erlidir. (Global)
            }

    console.log(kdvOrani);

    console.log(" let ----------------------------");

   // let isim = "vedat";

    console.log(isim); // Daha �nceden tan�mlanm�� bir de�i�ken ismi let kullan�larak ayn� blok i�inde tekrar tan�mlanamaz. Hata verir. Recreation a kapal�.

    let sayac = 0;
    //  let sayac = 55; //yaz�lamaz. hata verir.

    console.log("Ana blokta:" + sayac);

            {
                let sayac = 1; // farkl� bir blok i�erisinde let ile ayn� isimli bir de�i�ken tan�mlanabilir. Fakat bu de�i�ken sadece bu blokta ge�erlidir ve �nceki blokta tan�mlanan de�i�kenden ayr� bir de�i�kendir. Blok sona erince bu de�i�ken haf�zadan at�l�r. 
                console.log("i� blokta:"+sayac); 
            }

    console.log("Ana blokta:" + sayac);   

    {
        let scopeDegiskeni = "Burada ge�erliyim";
        console.log(scopeDegiskeni); 
    }

    // console.log(scopeDegiskeni); //let ile tan�mlanan de�i�ken bloktan ��k�ld���nda haf�zadan at�l�r. Art�k bu de�i�ken haf�zada olmad��� bu kod hata verir. Kodun sonraki sat�rlar�n� engellememesi i�in kapat�ld�.

    console.log("Test");

    console.log(" const ----------------------------");

    var s1;
    console.log(s1);
    s1 = 50;
    console.log(s1);

    let s2;
    console.log(s2);
    s2 = 100;
    console.log(s2);

    const kdv = 50; // const ifadesi ile tan�mlanan bir de�i�kene ilk de�er atamas�, tan�mlama esnas�nda yap�lmak zorundad�r ve ilk de�er atamas� yap�lmadan bu de�i�ken kullan�lamaz. Yoksa kod hata verir ve �al��maz.
    
    // const kdv2; Bu sat�r �al��maz, hata verir. Nedeni ilk de�eri atamas� yap�lmam��.

   // const kdv = 25; Bu sat�r �al��maz. Nedeni, const ifadesinde de ayn� let ifadesinde oldu�u gibi, ayn� scope i�inde ayn� isimde birden fazla de�i�ken tan�mlanamaz. Hata verir.

    //var ve let ile tan�mlanan de�i�kenler ise ilk de�er atamas� yap�lmadan kullan�labilirler ve kod hata vermez.Bu durumda de�er, program�n kullan�m� esnas�nda "undefined" olarak g�r�n�r. ��nk� de�er atanmad��� i�in de�ikenin tipi de nen�z belli de�ldir. De�erin "undefined" olarak g�r�nmemesi i�in bu de�i�kenlere, kullan�lmadan �nce ilk de�er atamas� yap�lmal�d�r. Bunlar�n ilk de�er atamalar� tan�mlama esnas�nda yap�lmak zorunda de�ildir. Sonradan da yap�labilir.

    console.log(kdv);

    // kdv = 75; const ile tan�mlanm�� bir de�i�kene tekrar de�er atamas� yap�lamaz. Sadece ilk tan�mlama esnas�nda de�er atan�r ve program boyunca de�i�tirilemez. Sabittir. Bu kod hata verir.

    console.log(kdv);

    // this keyword� ile bir aral�kta yeni de�i�kenler yarat�labilir. ayn� var ile tan�mlanm�� gibi davranan de�i�kenler olu�ur. bunlara this local de�i�kenleri denir.

    this.adet = 85;

    this.sayac = 10;

    this.kdv = 1000;

    kalem = 5000; // e�er bir de�i�ken de�eri atama ifadesinde var, let, const, this. ifadelerinden biri kullan�lmadan de�i�ken tan�mlanacak olursa, bu �ekilde yarat�lan de�i�kene tan�ms�z de�i�en denir. Tan�ms�z de�i�kenler var ile tan�mlanan de�i�kenler gibi davran�r. Kullan�m� �nerilmez.

    console.log("adet de�eri:" + this.adet);
    console.log("sayac de�eri:" + this.sayac);
    console.log("kdv de�eri:" + this.kdv);

    console.log(kalem);
    console.log(bardak = 50);


}




